package BrowserFactory;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseClass {
	
    public static WebDriver driver;
	public Properties prop;
	

	public WebDriver openBrowser(String browser)
	{
		if(browser.equalsIgnoreCase("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\91808\\Desktop\\driverchrome\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		}
		if(browser.equalsIgnoreCase("FireFox"))
		{	
			System.setProperty("webdriver.gecko.driver","C:\\Users\\91808\\Desktop\\driverchrome\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		}
		driver.manage().window().maximize();
		return driver;
	}
	
	public BaseClass(){
			prop = new Properties();
			FileInputStream str;
			try {
				str = new FileInputStream(System.getProperty("user.dir")+"/src/main/java/config/config.properties");
				prop.load(str);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		 
	}
	
	
	
	
}
