package ZestMoneyTest;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import BrowserFactory.BaseClass;
import TestPage.Login;

public class ZestMoneyTest extends BaseClass {
	//public WebDriver driver;
	String Amazon;
	String FlipKart;
	BaseClass bs;
	String productName;
	String productName1;

	String PriceofF;
	String PriceofAm;
	
	@BeforeMethod
	public void setUP(){
		bs = new BaseClass();
		bs.openBrowser("FireFox");
		Amazon = prop.getProperty("URL1");
		FlipKart = prop.getProperty("URL2");
		productName = prop.getProperty("productName");
		productName1 = prop.getProperty("productName1");
		
	}
	@Test(priority = 1)
	public void FlipKartTest() throws InterruptedException{
		driver.get(FlipKart);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.navigate().back();
		driver.findElement(By.xpath("//button[@class='_2AkmmA _29YdH8']")).click();
		driver.findElement(By.xpath("//input[@name =  'q']")).sendKeys(productName);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.xpath("//div[@class='_6BWGkk']")).getText();
		Comparable<String> p1= PriceofF.substring(1);
		System.out.println("product price is : "+ p1);
		
	

		driver.get(Amazon);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(productName1);
		driver.findElement(By.xpath("//input[@value= 'Go']")).click();
		PriceofAm = driver.findElement(By.xpath("//span[@class= 'a-price-whole']")).getText();
		System.out.println("Price of amazon is : "+ PriceofAm);
		
		
		
}
	
	@AfterMethod
	public void tearDown()
	{
		
	}
	
}
