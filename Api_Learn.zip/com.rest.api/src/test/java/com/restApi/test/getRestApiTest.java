package com.restApi.test;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.Header;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.client.CreateClient;
import com.qa.utils.UtilsClass;

import BasePackage.BaseClass;

public class getRestApiTest extends BaseClass {
	CreateClient RestClient;
	String Url;
	String ServiceUrl;
	String url;
	int statusCode;
	BaseClass base;
	CloseableHttpResponse HttpResponse;
	@BeforeMethod
	public void SetUp()throws ClientProtocolException, IOException{
		base = new BaseClass();
		Url = prop.getProperty("url");
		ServiceUrl = prop.getProperty("serviceUrl");
	    url = Url+ServiceUrl;
		
		
	}
	
	@Test
	public void RestHttpTest() throws ClientProtocolException, IOException, JSONException{
		RestClient = new CreateClient();	
		RestClient.get(url);
	
}
}
