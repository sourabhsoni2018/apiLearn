package com.restApi.test;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.apache.http.Header;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.client.PostCreateClient;
import com.qa.users.Users;

import BasePackage.BaseClass;

public class postRestApiTest extends BaseClass {
	
	String URL;
	String ServiceUrl;
	String url;
	CloseableHttpResponse HttpResponse;
	PostCreateClient post;
	BaseClass baseclass;
	PostCreateClient PostClient;
	@BeforeMethod
	public void setUp(){
		baseclass = new BaseClass();
		URL = prop.getProperty("url");
		ServiceUrl = prop.getProperty("serviceUrl");
		url = URL+ServiceUrl;
		
		
	}
	@Test
	public void PostApiTest() throws ClientProtocolException, IOException, JSONException{
		PostClient = new PostCreateClient();
		HashMap<String, String> Hash = new HashMap<String, String>();
		Hash.put("Authorization", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyZGM2NTA0Ny0xMDJiLTRhZmItODBmZC01MDViMjQ5Zjk4NzgifQ._ydlVXI0Da94gxKPWQyvRua7JCGQwrjg_2B6POcTzfMJP_N8Spb1gNpvRcalq9DHhnyCT7drbNv7a044k4yfew");
		Hash.put("Content-Type","application/json");
		ObjectMapper mapper = new ObjectMapper();
		
		Users user = new Users();
		user.setFrom("2019-04-01");// Expected Users Object
		user.setTo("2019-05-03");
		mapper.writeValue(new File("C:/Users/91808/Desktop/Appium_Script/com.rest.api/src/main/java/com/qa/users/user.JSON"), user);
		
		String ObjectMapperString = mapper.writeValueAsString(user);
		System.out.println(ObjectMapperString);
		
		
		
		CloseableHttpResponse HttpResponse = PostClient.postUrl(url, ObjectMapperString, Hash);

		int statusCode = HttpResponse.getStatusLine().getStatusCode();
		System.out.println(statusCode);
		
			
		String ResponseString = EntityUtils.toString(HttpResponse.getEntity(),"UTF-8");
		JSONObject jsonObject = new JSONObject(ResponseString);
		
		Users userObject = mapper.readValue(ResponseString, Users.class);
		System.out.println(userObject);
		//GetHeader

		
	}

}
