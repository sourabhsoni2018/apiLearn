package com.qa.client;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.Header;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class PostCreateClient {
	
	public CloseableHttpResponse postUrl(String url, String entiryString, HashMap<String, String> HeaderMap) throws ClientProtocolException, IOException, JSONException
	{
		CloseableHttpClient closeableHttpClients= HttpClients.createDefault();
		HttpPost HttpUrl = new HttpPost(url);
		HttpUrl.setEntity(new StringEntity(entiryString));
		// For Add Body
		for(Map.Entry<String, String> entry : HeaderMap.entrySet())
		{
			HttpUrl.addHeader(entry.getKey(), entry.getValue());
		}
		
		CloseableHttpResponse HttpResponse = closeableHttpClients.execute(HttpUrl);
		return HttpResponse;
	}
	public CloseableHttpResponse postUrl(String url, HashMap<String, String> HeaderMap) throws ClientProtocolException, IOException
	{
		CloseableHttpClient closeableHttpClients= HttpClients.createDefault();
		HttpPost HttpUrl = new HttpPost(url);
		for(Map.Entry<String, String> entry : HeaderMap.entrySet() )
		{
			HttpUrl.addHeader(entry.getKey(), entry.getValue());
		}
		CloseableHttpResponse HttpResponse = closeableHttpClients.execute(HttpUrl);
		return HttpResponse;
				
	}

}
