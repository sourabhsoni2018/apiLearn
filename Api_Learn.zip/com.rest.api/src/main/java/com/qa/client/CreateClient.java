package com.qa.client;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.Header;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class CreateClient {
	
	public void get(String url) throws ClientProtocolException, IOException, JSONException
	{
		CloseableHttpClient closeablettpClient = HttpClients.createDefault();
		HttpGet getUrl = new HttpGet(url);
		CloseableHttpResponse HttpResponse = closeablettpClient.execute(getUrl);
		int Status = HttpResponse.getStatusLine().getStatusCode();
		System.out.println(Status);
		
		String ResponseString = EntityUtils.toString(HttpResponse.getEntity(),"UTF-8");
		JSONObject jsonObject = new JSONObject(ResponseString);
		System.out.println(jsonObject);
		
		// get header-------------------------------------------->
		
		Header[] Httpheader = HttpResponse.getAllHeaders();
		HashMap<String, String> AllHeader = new HashMap<String, String>();
		for(Header head : Httpheader){
			
			AllHeader.put(head.getName(), head.getValue());
				
			
		}
		System.out.println(AllHeader);
	}
	
	
	

}
